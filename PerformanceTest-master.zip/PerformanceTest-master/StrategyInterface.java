public interface StrategyInterface {

    public int calculate(String s);
    
}
