public class FileName {

    public String name;

    public FileName(String name) {
	this.name = name;
    }
}
